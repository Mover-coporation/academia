
<?php if(empty($ignore_resize)){?>
<script type="text/javascript">
$(document).ready(function() {
	var tableHeight = $('#contentdiv').height();
	//$('#leftmenu').height(tableHeight);
});
</script>
<?php }?>
<tr>
    <td colspan="3" valign="top" align="center">
<table  border="0" cellspacing="0" cellpadding="0">
<tr>
    <td height="19" class="footertext">&copy;<?php echo date('Y');?> | New Wave Technologies Limited. All Rights Reserved | Contact Support By <a href="mailto:info@newwavetech.co.ug" class="footertext">Email</a> | Call +256 41 4389 220<br />
    <input type="hidden" id="layerid" value="" />
   </td>
  </tr>
   </table>
</td>
</tr>